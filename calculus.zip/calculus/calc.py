import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from matplotlib.animation import PillowWriter
import sympy as sy
from sympy import pi
import japanize_matplotlib

def calugul(EQ,x):
    global m
    while True:
        mode = str(input("微分/積分(b/s):"))

        if(mode == "b"):
            ans = sy.diff(EQ,x)
            print(f'{"微分結果:"}{ans}')
            m = "微分"
            break

        elif(mode == "s"):
            ans = sy.integrate(EQ,x)
            print(f'{"積分結果:"}{ans}')
            m = "積分"
            break

        else:
            pass

    return ans

def c_nan(NP):
    df = pd.DataFrame(NP)
    df = df.fillna(0)
    c_NP = df.to_numpy()

    return c_NP

def generate_graph(data):
    global func1,func2,line1,line2,title
    x = np.linspace(-10,data/10,1000)
    y1 = c_nan(func1(x))
    y2 = c_nan(func2(x))

    line1.set_data(x,y1)
    line2.set_data(x,y2)
    title.set_text("x: {}".format((max(x))))

def main():
    global func1,func2,line1,line2,title
    x = sy.Symbol("x")
    e = sy.E

    eq = input("式:")
    args = (x)

    ANS = calugul(eq,x)

    func1 = sy.lambdify(args,eq,"numpy")
    func2 = sy.lambdify(args,ANS,"numpy")
    x = np.arange(-10,10,dtype = float)

    y_max = max(max(c_nan(func1(x))),max(c_nan(func2(x))))
    y_min = min(min(c_nan(func1(x))),min(c_nan(func2(x))))

    fig,ax = plt.subplots()
    line1, = ax.plot(np.empty(0),np.empty(0),color = "blue",label = "演算前")
    line2, = ax.plot(np.empty(0),np.empty(0),color = "red",label = "演算後")
    title = ax.set_title(None, fontsize=15)

    ax.set_xlim(-10,10)
    ax.set_ylim(y_min,y_max)
    ax.grid()
    ax.legend()
    ax.set_xlabel("x")
    ax.set_ylabel("y")

    ani = FuncAnimation(
        fig,
        generate_graph,
        frames = range(-100,101),
        interval=20,
        repeat_delay = 1000)

    plt.show()

    eq_r = eq.replace('**','^').replace("*","×")

    while True:
        var = str(input("保存形式:gif/mp4/None(g/m/n)"))

        if(var == "g"):
            ani.save(eq_r + "_" + m +".gif", writer = 'pillow',fps = 30)
            break

        elif(var == "m"):
            ani.save(eq_r + "_" + m + ".mp4", writer="ffmpeg", fps = 30, bitrate=1000)
            break

        elif(var == "n"):
            break

if __name__ == "__main__":
    main()