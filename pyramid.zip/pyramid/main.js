// main.js
console.log("main.js実行開始"); // 動作確認のためログに出力する。
// ソースコード始め

// ユーザインタフェースをidで探し、変数に代入する。
let value = []
let FLAG1 = false
let FLAG2 = false
let stack = []
let opencard = []
var bt = document.getElementById('button1');
let BAN = []
var randoms = [];
let YAMAHUDA_I

function intRandom(min, max){
    return Math.floor(Math.random() * (max - min + 1)) + min;
}
let images = [
  {card:'tramp\\d01.png',i:1},{card:'tramp\\d02.png',i:2},{card:'tramp\\d01.png',i:3},
  {card:'tramp\\d04.png',i:4},{card:'tramp\\d05.png',i:5},{card:'tramp\\d06.png',i:6},
  {card:'tramp\\d07.png',i:7},{card:'tramp\\d08.png',i:8},{card:'tramp\\d09.png',i:9},
  {card:'tramp\\d10.png',i:10},{card:'tramp\\d11.png',i:11},{card:'tramp\\d12.png',i:12},
  {card:'tramp\\d13.png',i:13},
  {card:'tramp\\k01.png',i:1},{card:'tramp\\k02.png',i:2},{card:'tramp\\k03.png',i:3},
  {card:'tramp\\k04.png',i:4},{card:'tramp\\k05.png',i:5},{card:'tramp\\k06.png',i:6},
  {card:'tramp\\k07.png',i:7},{card:'tramp\\k08.png',i:8},{card:'tramp\\k09.png',i:9},
  {card:'tramp\\k10.png',i:10},{card:'tramp\\k11.png',i:11},{card:'tramp\\k12.png',i:12},
  {card:'tramp\\k13.png',i:13},
  {card:'tramp\\s01.png',i:1},{card:'tramp\\s02.png',i:2},{card:'tramp\\s03.png',i:3},
  {card:'tramp\\s04.png',i:4},{card:'tramp\\s05.png',i:5},{card:'tramp\\s06.png',i:6},
  {card:'tramp\\s07.png',i:7},{card:'tramp\\s08.png',i:8},{card:'tramp\\s09.png',i:9},
  {card:'tramp\\s10.png',i:10},{card:'tramp\\s11.png',i:11},{card:'tramp\\s12.png',i:12},
  {card:'tramp\\s13.png',i:13},
  {card:'tramp\\h01.png',i:1},{card:'tramp\\h02.png',i:2},{card:'tramp\\h03.png',i:3},
  {card:'tramp\\h04.png',i:4},{card:'tramp\\h05.png',i:5},{card:'tramp\\h06.png',i:6},
  {card:'tramp\\h07.png',i:7},{card:'tramp\\h08.png',i:8},{card:'tramp\\h09.png',i:9},
  {card:'tramp\\h10.png',i:10},{card:'tramp\\h11.png',i:11},{card:'tramp\\h12.png',i:12},
  {card:'tramp\\h13.png',i:13},
  ];
function checkCARD(OPEN,AF,AH){
  for(let i = 0; i < 28; i++){
      if(OPEN.includes(i)){
        AF[i].removeEventListener('click',AH[i])
      }
  }
  //1段目
  if(OPEN.includes(0)){
    alert("クリア")
  }
  if(OPEN.includes(1) && OPEN.includes(2)){
    field1.addEventListener('click', handle1);
  }
  //2段目
  if(OPEN.includes(3) && OPEN.includes(4)){
    field2.addEventListener('click', handle2);
  }
  if(OPEN.includes(4) && OPEN.includes(5)){
    field3.addEventListener('click', handle3);
  }
  //3段目
  if(OPEN.includes(6) && OPEN.includes(7)){
    field4.addEventListener('click', handle4);
  }
  if(OPEN.includes(7) && OPEN.includes(8)){
    field5.addEventListener('click', handle5);
  }
  if(OPEN.includes(8) && OPEN.includes(9)){
    field6.addEventListener('click', handle6);
  }
  //4段目
  if(OPEN.includes(10) && OPEN.includes(11)){
    field7.addEventListener('click', handle7);
  }
  if(OPEN.includes(11) && OPEN.includes(12)){
    field8.addEventListener('click', handle8);
  }
  if(OPEN.includes(12) && OPEN.includes(13)){
    field9.addEventListener('click', handle9);
  }
  if(OPEN.includes(13) && OPEN.includes(14)){
    field10.addEventListener('click', handle9);
  }
  //5段目
  if(OPEN.includes(15) && OPEN.includes(16)){
    field11.addEventListener('click', handle10);
  }
  if(OPEN.includes(16) && OPEN.includes(17)){
    field12.addEventListener('click', handle11);
  }
  if(OPEN.includes(17) && OPEN.includes(18)){
    field13.addEventListener('click', handle12);
  }
  if(OPEN.includes(18) && OPEN.includes(19)){
    field14.addEventListener('click', handle13);
  }
  if(OPEN.includes(19) && OPEN.includes(20)){
    field15.addEventListener('click', handle14);
  }
  //6段目
  if(OPEN.includes(21) && OPEN.includes(22)){
    field16.addEventListener('click', handle16);
  }
  if(OPEN.includes(22) && OPEN.includes(23)){
    field17.addEventListener('click', handle17);
  }
  if(OPEN.includes(23) && OPEN.includes(24)){
    field18.addEventListener('click', handle18);
  }
  if(OPEN.includes(24) && OPEN.includes(25)){
    field19.addEventListener('click', handle19);
  }
  if(OPEN.includes(25) && OPEN.includes(26)){
    field20.addEventListener('click', handle20);
  }
  if(OPEN.includes(26) && OPEN.includes(27)){
    field21.addEventListener('click', handle21);
  }
}

function toggleCardSelection(cardElement) {
  cardElement.classList.toggle('selected');
}

bt.addEventListener('click',function(e){
  FLAG1 = false
  yamahuda1.addEventListener('click', handle_yamahuda1);
  yamahuda2.addEventListener('click', handle_yamahuda2);

value = []
var min = 0, max = 51;
for(i = 0; i < 28; i++){
    while(true){
      var tmp = intRandom(min, max);
      if(!randoms.includes(tmp)){
        randoms.push(tmp);
        break;
      }
    }
  }

for(let i = 1; i < 29; i++){
    var field = document.getElementById('field' + i);
    index = randoms[i-1]
    var element = images[index];
    field.src = element.card;
    value.push(element.i)
};
BAN = randoms.concat();
},false);



//カードの選択
var field1 = document.getElementById('field1')
var field2 = document.getElementById('field2')
var field3 = document.getElementById('field3')
var field4 = document.getElementById('field4')
var field5 = document.getElementById('field5')
var field6 = document.getElementById('field6')
var field7 = document.getElementById('field7')
var field8 = document.getElementById('field8')
var field9 = document.getElementById('field9')
var field10 = document.getElementById('field10')
var field11 = document.getElementById('field11')
var field12 = document.getElementById('field12')
var field13 = document.getElementById('field13')
var field14 = document.getElementById('field14')
var field15 = document.getElementById('field15')
var field16 = document.getElementById('field16')
var field17 = document.getElementById('field17')
var field18 = document.getElementById('field18')
var field19 = document.getElementById('field19')
var field20 = document.getElementById('field20')
var field21 = document.getElementById('field21')
var field22 = document.getElementById('field22')
var field23 = document.getElementById('field23')
var field24 = document.getElementById('field24')
var field25 = document.getElementById('field25')
var field26 = document.getElementById('field26')
var field27 = document.getElementById('field27')
var field28 = document.getElementById('field28')
var yamahuda1 = document.getElementById('yamahuda1')
var yamahuda2 = document.getElementById('yamahuda2')

var allfield = [
  field1, field2, field3, field4, field5, field6,
  field7, field8, field9, field10, field11, field12,
  field13, field14, field15, field16, field17, field18,
  field19, field20, field21, field22, field23 , field24,
  field25, field26, field27, field28, yamahuda2
]

const handle1 = () => {
  const cardElement = document.getElementById('field1');
  if(FLAG1){
    if (stack.some(card=>card.f===0)){
      resetSelection();
      return;
    }
    stack.push({v:value[0],f:0});
    toggleCardSelection(cardElement);
    if(13 == stack[0].v + stack[1].v){
      allfield[stack[0].f].src = 'tramp\\null.png';
      allfield[stack[1].f].src = 'tramp\\null.png';
      opencard.push(stack[0].f,stack[1].f)
      FLAG1 = false;
      resetSelection();
    }
    else{
      alert("消せません")
      resetSelection();
    }
  }
  else{
    FLAG1 = true;
    console.log(value[0]);
    if(value[0] == 13){
      field1.src = 'tramp\\null.png';
      opencard.push(0)
      FLAG1 = false;
      resetSelection();
    }
    else{
      stack.push({v:value[0],f:0});
      toggleCardSelection(cardElement);
    }
  };
  checkCARD(opencard,allfield,Allhandle)
};

const handle2 = () => {
  const cardElement = document.getElementById('field2');
  if(FLAG1){
    if (stack.some(card => card.f===1)){
      resetSelection();
      return;
    }
    stack.push({v:value[1],f:1});
    toggleCardSelection(cardElement);
    if(13 == stack[0].v + stack[1].v){
      allfield[stack[0].f].src = 'tramp\\null.png';
      allfield[stack[1].f].src = 'tramp\\null.png';
      opencard.push(stack[0].f,stack[1].f)
      FLAG1 = false;
      resetSelection();
    }
    else{
      alert("消せません")
      resetSelection();
    }
  }
  else{
    FLAG1 = true;
    if(value[1] == 13){
      field2.src = 'tramp\\null.png';
      opencard.push(1)
      FLAG1 = false
      resetSelection();
    }
    else{
      stack.push({v:value[1],f:1});
      toggleCardSelection(cardElement);
    }
  };
  checkCARD(opencard,allfield,Allhandle)
}

const handle3 = () => {
  const cardElement = document.getElementById('field3');
  if(FLAG1){
    if (stack.some(card => card.f===2)){
      resetSelection();
      return;
    }
    stack.push({v:value[2],f:2});
    toggleCardSelection(cardElement);
    if(13 == stack[0].v + stack[1].v){
      allfield[stack[0].f].src = 'tramp\\null.png';
      allfield[stack[1].f].src = 'tramp\\null.png';
      opencard.push(stack[0].f,stack[1].f)
      FLAG1 = false;
      resetSelection();
    }
    else{
      alert("消せません")
      resetSelection();
    }
  }
  else{
    FLAG1 = true;
    if(value[2] == 13){
      field3.src = 'tramp\\null.png';
      opencard.push(2)
      FLAG1 = false;
      resetSelection();
    }
    else{
      stack.push({v:value[2],f:2});
      toggleCardSelection(cardElement);
    }
  };
  checkCARD(opencard,allfield,Allhandle)
}

const handle4 = () => {
  const cardElement = document.getElementById('field4');
  if(FLAG1){
    if (stack.some(card => card.f===3)){
      resetSelection();
      return;
    }
    stack.push({v:value[3],f:3});
    toggleCardSelection(cardElement);
    if(13 == stack[0].v + stack[1].v){
      allfield[stack[0].f].src = 'tramp\\null.png';
      allfield[stack[1].f].src = 'tramp\\null.png';
      opencard.push(stack[0].f,stack[1].f)
      FLAG1 = false;
      resetSelection();
    }
    else{
      alert("消せません")
      resetSelection();
    }
  }
  else{
    FLAG1 = true;
    if(value[3] == 13){
      field4.src = 'tramp\\null.png';
      opencard.push(3)
      FLAG1 = false;
      resetSelection();
    }
    else{
      stack.push({v:value[3],f:3});
      toggleCardSelection(cardElement);
    }
  };
  checkCARD(opencard,allfield,Allhandle)
}

const handle5 = () => {
  const cardElement = document.getElementById('field5');
  if(FLAG1){
    if (stack.some(card => card.f===4)){
      resetSelection();
      return;
    }
    stack.push({v:value[4],f:4});
    toggleCardSelection(cardElement);
    if(13 == stack[0].v + stack[1].v){
      allfield[stack[0].f].src = 'tramp\\null.png';
      allfield[stack[1].f].src = 'tramp\\null.png';
      opencard.push(stack[0].f,stack[1].f)
      FLAG1 = false;
      resetSelection();
    }
    else{
      alert("消せません")
      resetSelection();
    }
  }
  else{
    FLAG1 = true;
    if(value[4] == 13){
      field5.src = 'tramp\\null.png';
      opencard.push(4)
      FLAG1 = false;
      resetSelection();
    }
    else{
      stack.push({v:value[4],f:4});
      toggleCardSelection(cardElement);
    }
  };
  checkCARD(opencard,allfield,Allhandle)
}

const handle6 = () => {
  const cardElement = document.getElementById('field6');
  if(FLAG1){
    if (stack.some(card => card.f===5)){
      resetSelection();
      return;
    }
    stack.push({v:value[5],f:5});
    toggleCardSelection(cardElement);
    if(13 == stack[0].v + stack[1].v){
      allfield[stack[0].f].src = 'tramp\\null.png';
      allfield[stack[1].f].src = 'tramp\\null.png';
      opencard.push(stack[0].f,stack[1].f)
      FLAG1 = false;
      resetSelection();
    }
    else{
      alert("消せません")
      resetSelection();
    }
  }
  else{
    FLAG1 = true;
    if(value[5] == 13){
      field6.src = 'tramp\\null.png';
      opencard.push(5)
      FLAG1 = false;
      resetSelection();
    }
    else{
      stack.push({v:value[5],f:5});
      toggleCardSelection(cardElement);
    }
  };
  checkCARD(opencard,allfield,Allhandle)
}

const handle7 = () => {
  const cardElement = document.getElementById('field7');
  if(FLAG1){
    if (stack.some(card => card.f===6)){
      resetSelection();
      return;
    }
    stack.push({v:value[6],f:6});
    toggleCardSelection(cardElement);
    if(13 == stack[0].v + stack[1].v){
      allfield[stack[0].f].src = 'tramp\\null.png';
      allfield[stack[1].f].src = 'tramp\\null.png';
      opencard.push(stack[0].f,stack[1].f)
      FLAG1 = false;
      resetSelection();
    }
    else{
      alert("消せません")
      resetSelection();
    }
  }
  else{
    FLAG1 = true;
    if(value[6] == 13){
      field7.src = 'tramp\\null.png';
      opencard.push(6)
      FLAG1 = false
      resetSelection();
    }
    else{
      stack.push({v:value[6],f:6});
      toggleCardSelection(cardElement);
    }
  };
  checkCARD(opencard,allfield,Allhandle)
}

const handle8 = () => {
  const cardElement = document.getElementById('field8');
  if(FLAG1){
    if (stack.some(card => card.f===7)){
      resetSelection();
      return;
    }
    stack.push({v:value[7],f:7});
    toggleCardSelection(cardElement);
    if(13 == stack[0].v + stack[1].v){
      allfield[stack[0].f].src = 'tramp\\null.png';
      allfield[stack[1].f].src = 'tramp\\null.png';
      opencard.push(stack[0].f,stack[1].f)
      FLAG1 = false;
      resetSelection();
    }
    else{
      alert("消せません")
      resetSelection();
    }
  }
  else{
    FLAG1 = true;
    if(value[7] == 13){
      field8.src = 'tramp\\null.png';
      opencard.push(7)
      FLAG1 = false;
      resetSelection();
    }
    else{
      stack.push({v:value[7],f:7});
      toggleCardSelection(cardElement);
    }
  };
  checkCARD(opencard,allfield,Allhandle)
}

const handle9 = () => {
  const cardElement = document.getElementById('field9');
  if(FLAG1){
    if (stack.some(card => card.f===8)){
      resetSelection();
      return;
    }
    stack.push({v:value[8],f:8});
    toggleCardSelection(cardElement);
    if(13 == stack[0].v + stack[1].v){
      allfield[stack[0].f].src = 'tramp\\null.png';
      allfield[stack[1].f].src = 'tramp\\null.png';
      opencard.push(stack[0].f,stack[1].f)
      FLAG1 = false;
      resetSelection();
    }
    else{
      alert("消せません")
      resetSelection();
    }
  }
  else{
    FLAG1 = true;
    if(value[8] == 13){
      field9.src = 'tramp\\null.png';
      opencard.push(8)
      FLAG1 = false;
      resetSelection();
    }
    else{
      stack.push({v:value[8],f:8});
      toggleCardSelection(cardElement);
    }
  };
  checkCARD(opencard,allfield,Allhandle)
}

const handle10 = () => {
  const cardElement = document.getElementById('field10');
  if(FLAG1){
    if (stack.some(card => card.f===9)){
      resetSelection();
      return;
    }
    stack.push({v:value[9],f:9});
    toggleCardSelection(cardElement);
    if(13 == stack[0].v + stack[1].v){
      allfield[stack[0].f].src = 'tramp\\null.png';
      allfield[stack[1].f].src = 'tramp\\null.png';
      opencard.push(stack[0].f,stack[1].f)
      FLAG1 = false;
      resetSelection();
    }
    else{
      alert("消せません")
      resetSelection();
    }
  }
  else{
    FLAG1 = true;
    if(value[9] == 13){
      field10.src = 'tramp\\null.png';
      opencard.push(9)
      FLAG1 = false;
      resetSelection();
    }
    else{
      stack.push({v:value[9],f:9});
      toggleCardSelection(cardElement);
    }
  };
  checkCARD(opencard,allfield,Allhandle)
}

const handle11 = () => {
  const cardElement = document.getElementById('field11');
  if(FLAG1){
    if (stack.some(card => card.f===10)){
      resetSelection();
      return;
    }
    stack.push({v:value[10],f:10});
    toggleCardSelection(cardElement);
    if(13 == stack[0].v + stack[1].v){
      allfield[stack[0].f].src = 'tramp\\null.png';
      allfield[stack[1].f].src = 'tramp\\null.png';
      opencard.push(stack[0].f,stack[1].f)
      FLAG1 = false;
      resetSelection();
    }
    else{
      alert("消せません");
      resetSelection();
    }
  }
  else{
    FLAG1 = true;
    if(value[10] == 13){
      field11.src = 'tramp\\null.png';
      opencard.push(10)
      FLAG1 = false;
      resetSelection();
    }
    else{
      stack.push({v:value[10],f:10});
      toggleCardSelection(cardElement);
    }
  };
  checkCARD(opencard,allfield,Allhandle)
}

const handle12 = () => {
  const cardElement = document.getElementById('field12');
  if(FLAG1){
    if (stack.some(card => card.f===11)){
      resetSelection();
      return;
    }
    stack.push({v:value[11],f:11});
    toggleCardSelection(cardElement);
    if(13 == stack[0].v + stack[1].v){
      allfield[stack[0].f].src = 'tramp\\null.png';
      allfield[stack[1].f].src = 'tramp\\null.png';
      opencard.push(stack[0].f,stack[1].f)
      FLAG1 = false;
      resetSelection();
    }
    else{
      alert("消せません");
      resetSelection();
    }
  }
  else{
    FLAG1 = true;
    if(value[11] == 13){
      field12.src = 'tramp\\null.png';
      opencard.push(11)
      FLAG1 = false;
      resetSelection();
    }
    else{
      stack.push({v:value[11],f:11});
      toggleCardSelection(cardElement);
    }
  };
  checkCARD(opencard,allfield,Allhandle)
}

const handle13 = () => {
  const cardElement = document.getElementById('field13');
  if(FLAG1){
    if (stack.some(card => card.f===12)){
      resetSelection();
      return;
    }
    stack.push({v:value[12],f:12});
    toggleCardSelection(cardElement);
    if(13 == stack[0].v + stack[1].v){
      allfield[stack[0].f].src = 'tramp\\null.png';
      allfield[stack[1].f].src = 'tramp\\null.png';
      opencard.push(stack[0].f,stack[1].f)
      FLAG1 = false;
      resetSelection();
    }
    else{
      alert("消せません");
      resetSelection();
    }
  }
  else{
    FLAG1 = true;
    if(value[12] == 13){
      field13.src = 'tramp\\null.png';
      opencard.push(12)
      FLAG1 = false;
      resetSelection();
    }
    else{
      stack.push({v:value[12],f:12});
      toggleCardSelection(cardElement);
    }
  };
  checkCARD(opencard,allfield,Allhandle)
}

const handle14 = () => {
  const cardElement = document.getElementById('field14');
  if(FLAG1){
    if (stack.some(card => card.f===13)){
      resetSelection();
      return;
    }
    stack.push({v:value[13],f:13});
    toggleCardSelection(cardElement);
    if(13 == stack[0].v + stack[1].v){
      allfield[stack[0].f].src = 'tramp\\null.png';
      allfield[stack[1].f].src = 'tramp\\null.png';
      opencard.push(stack[0].f,stack[1].f)
      FLAG1 = false;
      resetSelection();
    }
    else{
      alert("消せません");
      resetSelection();
    }
  }
  else{
    FLAG1 = true;
    if(value[13] == 13){
      field14.src = 'tramp\\null.png';
      opencard.push(13)
      FLAG1 = false;
      resetSelection();
    }
    else{
      stack.push({v:value[13],f:13});
      toggleCardSelection(cardElement);
    }
  };
  checkCARD(opencard,allfield,Allhandle)
}

const handle15 = () => {
  const cardElement = document.getElementById('field15');
  if(FLAG1){
    if (stack.some(card => card.f===14)){
      resetSelection();
      return;
    }
    stack.push({v:value[14],f:14});
    toggleCardSelection(cardElement);
    if(13 == stack[0].v + stack[1].v){
      allfield[stack[0].f].src = 'tramp\\null.png';
      allfield[stack[1].f].src = 'tramp\\null.png';
      opencard.push(stack[0].f,stack[1].f)
      FLAG1 = false;
      resetSelection();
    }
    else{
      alert("消せません");
      resetSelection();
    }
  }
  else{
    FLAG1 = true;
    if(value[14] == 13){
      field15.src = 'tramp\\null.png';
      opencard.push(14)
      FLAG1 = false;
      resetSelection();
    }
    else{
      stack.push({v:value[14],f:14});
      toggleCardSelection(cardElement);
    }
  };
  checkCARD(opencard,allfield,Allhandle)
}

const handle16 = () => {
  const cardElement = document.getElementById('field16');
  if(FLAG1){
    if (stack.some(card => card.f===15)){
      resetSelection();
      return;
    }
    stack.push({v:value[15],f:15});
    toggleCardSelection(cardElement);
    if(13 == stack[0].v + stack[1].v){
      allfield[stack[0].f].src = 'tramp\\null.png';
      allfield[stack[1].f].src = 'tramp\\null.png';
      opencard.push(stack[0].f,stack[1].f)
      FLAG1 = false;
      resetSelection();
    }
    else{
      alert("消せません");
      resetSelection();
    }
  }
  else{
    FLAG1 = true;
    if(value[15] == 13){
      field16.src = 'tramp\\null.png';
      opencard.push(15)
      FLAG1 = false;
      resetSelection();
    }
    else{
      stack.push({v:value[15],f:15});
      toggleCardSelection(cardElement);
    }
  };
  checkCARD(opencard,allfield,Allhandle)
}

const handle17 = () => {
  const cardElement = document.getElementById('field17');
  if(FLAG1){
    if (stack.some(card => card.f===16)){
      resetSelection();
      return;
    }
    stack.push({v:value[16],f:16});
    toggleCardSelection(cardElement);
    if(13 == stack[0].v + stack[1].v){
      allfield[stack[0].f].src = 'tramp\\null.png';
      allfield[stack[1].f].src = 'tramp\\null.png';
      opencard.push(stack[0].f,stack[1].f)
      FLAG1 = false;
      resetSelection();
    }
    else{
      alert("消せません");
      resetSelection();
    }
  }
  else{
    FLAG1 = true;
    if(value[16] == 13){
      field17.src = 'tramp\\null.png';
      opencard.push(16)
      FLAG1 = false;
      resetSelection();
    }
    else{
      stack.push({v:value[16],f:16});
      toggleCardSelection(cardElement);
    }
  };
  checkCARD(opencard,allfield,Allhandle)
}

const handle18 = () => {
  const cardElement = document.getElementById('field18');
  if(FLAG1){
    if (stack.some(card => card.f===17)){
      resetSelection();
      return;
    }
    stack.push({v:value[17],f:17});
    toggleCardSelection(cardElement);
    if(13 == stack[0].v + stack[1].v){
      allfield[stack[0].f].src = 'tramp\\null.png';
      allfield[stack[1].f].src = 'tramp\\null.png';
      opencard.push(stack[0].f,stack[1].f)
      FLAG1 = false;
      resetSelection();
    }
    else{
      alert("消せません");
      resetSelection();
    }
  }
  else{
    FLAG1 = true;
    if(value[17] == 13){
      field18.src = 'tramp\\null.png';
      opencard.push(17)
      FLAG1 = false;
      resetSelection();
    }
    else{
      stack.push({v:value[17],f:17});
      toggleCardSelection(cardElement);
    }
  };
  checkCARD(opencard,allfield,Allhandle)
}

const handle19 = () => {
  const cardElement = document.getElementById('field19');
  if(FLAG1){
    if (stack.some(card => card.f===18)){
      resetSelection();
      return;
    }
    stack.push({v:value[18],f:18});
    toggleCardSelection(cardElement);
    if(13 == stack[0].v + stack[1].v){
      allfield[stack[0].f].src = 'tramp\\null.png';
      allfield[stack[1].f].src = 'tramp\\null.png';
      opencard.push(stack[0].f,stack[1].f)
      FLAG1 = false;
      resetSelection();
    }
    else{
      alert("消せません");
      resetSelection();
    }
  }
  else{
    FLAG1 = true;
    if(value[18] == 13){
      field19.src = 'tramp\\null.png';
      opencard.push(18)
      FLAG1 = false;
      resetSelection();
    }
    else{
      stack.push({v:value[18],f:18});
      toggleCardSelection(cardElement);
    }
  };
  checkCARD(opencard,allfield,Allhandle)
}

const handle20 = () => {
  const cardElement = document.getElementById('field20');
  if(FLAG1){
    if (stack.some(card => card.f===19)){
      resetSelection();
      return;
    }
    stack.push({v:value[19],f:19});
    toggleCardSelection(cardElement);
    if(13 == stack[0].v + stack[1].v){
      allfield[stack[0].f].src = 'tramp\\null.png';
      allfield[stack[1].f].src = 'tramp\\null.png';
      opencard.push(stack[0].f,stack[1].f)
      FLAG1 = false;
      resetSelection();
    }
    else{
      alert("消せません");
      resetSelection();
    }
  }
  else{
    FLAG1 = true;
    if(value[19] == 13){
      field20.src = 'tramp\\null.png';
      opencard.push(19)
      FLAG1 = false;
      resetSelection();
    }
    else{
      stack.push({v:value[19],f:19});
      toggleCardSelection(cardElement);
    }
  };
  checkCARD(opencard,allfield,Allhandle)
}

const handle21 = () => {
  const cardElement = document.getElementById('field21');
  if(FLAG1){
    if (stack.some(card => card.f===20)){
      resetSelection();
      return;
    }
    stack.push({v:value[20],f:20});
    toggleCardSelection(cardElement);
    if(13 == stack[0].v + stack[1].v){
      allfield[stack[0].f].src = 'tramp\\null.png';
      allfield[stack[1].f].src = 'tramp\\null.png';
      opencard.push(stack[0].f,stack[1].f)
      FLAG1 = false;
      resetSelection();
    }
    else{
      alert("消せません");
      resetSelection();
    }
  }
  else{
    FLAG1 = true;
    if(value[20] == 13){
      field21.src = 'tramp\\null.png';
      opencard.push(20)
      FLAG1 = false;
      resetSelection();
    }
    else{
      stack.push({v:value[20],f:20});
      toggleCardSelection(cardElement);
    }
  };
  checkCARD(opencard,allfield,Allhandle)
}

const handle22 = () => {
  const cardElement = document.getElementById('field22');
  if(FLAG1){
    if (stack.some(card => card.f===21)){
      resetSelection();
      return;
    }
    stack.push({v:value[21],f:21});
    toggleCardSelection(cardElement);
    if(13 == stack[0].v + stack[1].v){
      allfield[stack[0].f].src = 'tramp\\null.png';
      allfield[stack[1].f].src = 'tramp\\null.png';
      opencard.push(stack[0].f,stack[1].f)
      FLAG1 = false;
      resetSelection();
    }
    else{
      alert("消せません");
      resetSelection();
    }
  }
  else{
    FLAG1 = true;
    if(value[21] == 13){
      field22.src = 'tramp\\null.png';
      opencard.push(21)
      FLAG1 = false;
      resetSelection();
    }
    else{
      stack.push({v:value[21],f:21});
      toggleCardSelection(cardElement);
    }
  };
  checkCARD(opencard,allfield,Allhandle)
}

const handle23 = () => {
  const cardElement = document.getElementById('field23');
  if(FLAG1){
    if (stack.some(card => card.f===22)){
      resetSelection();
      return;
    }
    stack.push({v:value[22],f:22});
    toggleCardSelection(cardElement);
    if(13 == stack[0].v + stack[1].v){
      allfield[stack[0].f].src = 'tramp\\null.png';
      allfield[stack[1].f].src = 'tramp\\null.png';
      opencard.push(stack[0].f,stack[1].f)
      FLAG1 = false;
      resetSelection();
    }
    else{
      alert("消せません");
      resetSelection();
    }
  }
  else{
    FLAG1 = true;
    if(value[22] == 13){
      field23.src = 'tramp\\null.png';
      opencard.push(22)
      FLAG1 = false;
      resetSelection();
    }
    else{
      stack.push({v:value[22],f:22});
      toggleCardSelection(cardElement);
    }
  };
  checkCARD(opencard,allfield,Allhandle)
}

const handle24 = () => {
  const cardElement = document.getElementById('field24');
  if(FLAG1){
    if (stack.some(card => card.f===23)){
      resetSelection();
      return;
    }
    stack.push({v:value[23],f:23});
    toggleCardSelection(cardElement);
    if(13 == stack[0].v + stack[1].v){
      allfield[stack[0].f].src = 'tramp\\null.png';
      allfield[stack[1].f].src = 'tramp\\null.png';
      opencard.push(stack[0].f,stack[1].f)
      FLAG1 = false;
      resetSelection();
    }
    else{
      alert("消せません");
      resetSelection();
    }
  }
  else{
    FLAG1 = true;
    if(value[23] == 13){
      field24.src = 'tramp\\null.png';
      opencard.push(23)
      FLAG1 = false;
      resetSelection();
    }
    else{
      stack.push({v:value[23],f:23});
      toggleCardSelection(cardElement);
    }
  };
  checkCARD(opencard,allfield,Allhandle)
}

const handle25 = () => {
  const cardElement = document.getElementById('field25');
  if(FLAG1){
    if (stack.some(card => card.f===24)){
      resetSelection();
      return;
    }
    stack.push({v:value[24],f:24});
    toggleCardSelection(cardElement);
    if(13 == stack[0].v + stack[1].v){
      allfield[stack[0].f].src = 'tramp\\null.png';
      allfield[stack[1].f].src = 'tramp\\null.png';
      opencard.push(stack[0].f,stack[1].f)
      FLAG1 = false;
      resetSelection();
    }
    else{
      alert("消せません");
      resetSelection();
    }
  }
  else{
    FLAG1 = true;
    if(value[24] == 13){
      field25.src = 'tramp\\null.png';
      opencard.push(24)
      FLAG1 = false;
      resetSelection();
    }
    else{
      stack.push({v:value[24],f:24});
      toggleCardSelection(cardElement);
    }
  };
  checkCARD(opencard,allfield,Allhandle)
}

const handle26 = () => {
  const cardElement = document.getElementById('field26');
  if(FLAG1){
    if (stack.some(card => card.f===25)){
      resetSelection();
      return;
    }
    stack.push({v:value[25],f:25});
    toggleCardSelection(cardElement);
    if(13 == stack[0].v + stack[1].v){
      allfield[stack[0].f].src = 'tramp\\null.png';
      allfield[stack[1].f].src = 'tramp\\null.png';
      opencard.push(stack[0].f,stack[1].f)
      FLAG1 = false;
      resetSelection();
    }
    else{
      alert("消せません");
      resetSelection();
    }
  }
  else{
    FLAG1 = true;
    if(value[25] == 13){
      field26.src = 'tramp\\null.png';
      opencard.push(25)
      FLAG1 = false;
      resetSelection();
    }
    else{
      stack.push({v:value[25],f:25});
      toggleCardSelection(cardElement);
    }
  };
  checkCARD(opencard,allfield,Allhandle)
}

const handle27 = () => {
  const cardElement = document.getElementById('field27');
  if(FLAG1){
    if (stack.some(card => card.f===26)){
      resetSelection();
      return;
    }
    stack.push({v:value[26],f:26});
    toggleCardSelection(cardElement);
    if(13 == stack[0].v + stack[1].v){
      allfield[stack[0].f].src = 'tramp\\null.png';
      allfield[stack[1].f].src = 'tramp\\null.png';
      opencard.push(stack[0].f,stack[1].f)
      FLAG1 = false;
      resetSelection();
    }
    else{
      alert("消せません");
      resetSelection();
    }
  }
  else{
    FLAG1 = true;
    if(value[26] == 13){
      field27.src = 'tramp\\null.png';
      opencard.push(26)
      FLAG1 = false;
      resetSelection();
    }
    else{
      stack.push({v:value[26],f:26});
      toggleCardSelection(cardElement);
    }
  };
  checkCARD(opencard,allfield,Allhandle)
}

const handle28 = () => {
  const cardElement = document.getElementById('field28');
  if(FLAG1){
    if (stack.some(card => card.f===27)){
      resetSelection();
      return;
    }
    stack.push({v:value[27],f:27});
    toggleCardSelection(cardElement);
    if(13 == stack[0].v + stack[1].v){
      allfield[stack[0].f].src = 'tramp\\null.png';
      allfield[stack[1].f].src = 'tramp\\null.png';
      opencard.push(stack[0].f,stack[1].f)
      FLAG1 = false;
      resetSelection();
    }
    else{
      alert("消せません");
      resetSelection();
    }
  }
  else{
    FLAG1 = true;
    if(value[27] == 13){
      field28.src = 'tramp\\null.png';
      opencard.push(27)
      FLAG1 = false;
      resetSelection();
    }
    else{
      stack.push({v:value[27],f:27});
      toggleCardSelection(cardElement);
    }
  };
  checkCARD(opencard,allfield,Allhandle)
}

const handle_yamahuda1 = () => {
  if(BAN.length == 52){
    BAN = randoms.concat();
  }
  else{
    while(true){
    var TMP = intRandom(0, 51);
    if(!BAN.includes(TMP)){
      yamahuda2.src = images[TMP-1].card
      YAMAHUDA_I = images[TMP-1].i
      BAN.push(TMP);
      break;
    }
  }
}
}

const handle_yamahuda2 = () => {
  const cardElement = document.getElementById("yamahuda2");
  if(FLAG1){
    if (stack.some(card => card.f === 28)){
      resetSelection();
      return;
    }
    stack.push({v:YAMAHUDA_I,f:28});
    toggleCardSelection(cardElement);
    if(13 == stack[0].v + stack[1].v){
      allfield[stack[0].f].src = 'tramp\\null.png';
      allfield[stack[1].f].src = 'tramp\\null.png';
      opencard.push(stack[0].f,stack[1].f)
      FLAG1 = false;
      resetSelection();
    }
    else{
      alert("消せません");
      resetSelection();
    }
  }
  else{
    FLAG1 = true;
    if(YAMAHUDA_I == 13){
      yamahuda2.src = 'tramp\\null.png';
      FLAG1 = false;
      resetSelection();
    }
    else{
      stack.push({v:YAMAHUDA_I,f:28});
      toggleCardSelection(cardElement);
    }
  };
  checkCARD(opencard,allfield,Allhandle)
}

const resetSelection = () => {
  stack.forEach(card => {
    if (card.f === 28) {
      const yamahudaElement = document.getElementById("yamahuda2");
      if (yamahudaElement) {
        toggleCardSelection(yamahudaElement);
      }
    } else {
      const cardElement = document.getElementById(`field${card.f + 1}`);
      toggleCardSelection(cardElement);
    }
  });
  stack = [];
  FLAG1 = false;
};

Allhandle = [
  handle1,handle2,handle3,handle4,handle5,handle6,
  handle7,handle8,handle9,handle10,handle11,handle12,
  handle13,handle14,handle15,handle16,handle17,handle18,
  handle19,handle20,handle21,handle22,handle23,handle24,
  handle25,handle26,handle27,handle28
]

field21.addEventListener('click', handle21);
field22.addEventListener('click', handle22);
field23.addEventListener('click', handle23);
field24.addEventListener('click', handle24);
field25.addEventListener('click', handle25);
field26.addEventListener('click', handle26);
field27.addEventListener('click', handle27);
field28.addEventListener('click', handle28);

console.log("main.js実行終了"); // 動作確認のためログに出力する。
