import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Button
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.material.TextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toComposeImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.WindowState
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberDialogState
import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import org.jetbrains.skia.Image
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread


@Composable
private fun Screen() {

    var postalcode by remember { mutableStateOf("") }
    var prefecture by remember { mutableStateOf("") }
    var city by remember { mutableStateOf("") }
    var town by remember { mutableStateOf("") }
    var other by remember { mutableStateOf("") }
    var save_flag by remember { mutableStateOf(false) }
    var dialog_successflag by remember { mutableStateOf(false) }
    var dialog_filefalseflag by remember { mutableStateOf(false) }
    var postflag by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // 郵便番号
        Row(
            modifier = Modifier.padding(0.dp, 0.dp, 5.dp, 5.dp).weight(1f),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "郵便番号",
                //fontSize = 10.sp,
                modifier = Modifier.weight(1f)
            )
            TextField(
                value = postalcode,
                onValueChange = { postalcode = it },
                modifier = Modifier.weight(2f),
                singleLine = true,
                maxLines = 1,
            )
            Button(
                modifier = Modifier.padding(3.dp, 0.dp, 0.dp, 0.dp).weight(1f),
                onClick = {
                    println("btn clicked")
                    val url = "https://zipcloud.ibsnet.co.jp/api/search?zipcode=" + postalcode
                    println("-> ${url}")
                    val thread = Thread(){
                        // Httpリクエストでデータ取得
                        val recv_msg = http_get(url)
                        // jsonをパース
                        try {
                            // Jsonオブジェクトを作成
                            val mapper = jacksonObjectMapper()
                            // Json文字列を読み込み
                            val root: JsonNode = mapper.readTree(recv_msg)

                            val node1 = root.get("results")  // 住所関連データ
                            val node_address = node1.get(0)

                            prefecture = node_address.get("address1").toString().replace("\"","")  // 都道府県
                            city = node_address.get("address2").toString().replace("\"","")    // 市町村区
                            town = node_address.get("address3").toString().replace("\"","")    // 町域名
                            save_flag = true

                        } catch (e: Exception) {
                            postflag = true
                        }
                    }.start()
                }
            ) {
                Text(text = "検索")
            }
        }

        //都道府県
        Row(
            modifier = Modifier.padding(0.dp, 0.dp, 5.dp, 5.dp).weight(1f),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "都道府県",
                //fontSize = 10.sp,
                modifier = Modifier.weight(1f)
            )
            TextField(
                value = prefecture,
                onValueChange = { prefecture },
                modifier = Modifier.weight(3f),
                singleLine = true,
                maxLines = 1,
            )
        }

        //市区町村
        Row(
            modifier = Modifier.padding(0.dp, 0.dp, 5.dp, 5.dp).weight(1f),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "市区町村",
                //fontSize = 10.sp,
                modifier = Modifier.weight(1f)
            )
            TextField(
                value = city,
                onValueChange = { city },
                modifier = Modifier.weight(3f),
                singleLine = true,
                maxLines = 1,
            )
        }

        //町域名
        Row(
            modifier = Modifier.padding(0.dp, 0.dp, 5.dp, 5.dp).weight(1f),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "町域名",
                //fontSize = 10.sp,
                modifier = Modifier.weight(1f)
            )
            TextField(
                value = town,
                onValueChange = {},
                modifier = Modifier.weight(3f),
                maxLines = 3,
            )
        }

        //その他番地
        Row(
            modifier = Modifier.padding(0.dp, 0.dp, 5.dp, 5.dp).weight(1f),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "その他番地",
                //fontSize = 10.sp,
                modifier = Modifier.weight(1f)
            )
            TextField(
                value = other,
                onValueChange = { other = it },
                modifier = Modifier.weight(3f),
                maxLines = 3,
            )
        }

        Button(
            modifier = Modifier.padding(5.dp, 0.dp, 0.dp, 0.dp).fillMaxWidth(),
            enabled = save_flag,
            onClick = {
                println("btn clicked")
                try{
                    val file = File("data/zipcode.csv")
                    file.appendText("${postalcode},${prefecture},${city},${town},${other}\n")
                    dialog_successflag = true
                }catch (e: Exception){
                    dialog_filefalseflag = true
                }
            }
        ) {
            Text(text = "保存")
        }
    }

    if (dialog_successflag) {
        MessageDialog("データが正常に保存されました.") {
            dialog_successflag = false
            save_flag = false //データ変更して保存させないため一度クローズさせる 7330011->1234567
        }
    } else if (dialog_filefalseflag) {
        MessageDialog("データが保存出来ませんでした.") {
            dialog_filefalseflag = false
        }
    }else if (postflag){
        MessageDialog("住所が取得できませんでした."){
            postflag = false
        }
    }
}


@Composable
private fun MessageDialog(msg: String, onClick: () -> Unit = {}) {
    Dialog(
        title = "メッセージ",
        state = rememberDialogState(width = 200.dp, height = 200.dp),
        onCloseRequest = onClick,
    ) {
        Column(modifier = Modifier.fillMaxSize().padding(10.dp)) {
            Text(msg, modifier = Modifier.weight(1f))
            Button(
                onClick = onClick
            ) {
                Text(text = "閉じる")
            }
        }
    }
}

// httpsクライアント（GET）
fun http_get(requestUrl: String): String {
    // URLオブジェクトを生成
    val url = URL(requestUrl)
    val urlConnection = url.openConnection() as HttpURLConnection
    urlConnection.requestMethod = "GET"

    // 接続し，ストリームをオープン
    urlConnection.connect()
    val br = BufferedReader(InputStreamReader(urlConnection.inputStream))
    //val sb = StringBuilder()
    var sb = ""
    // バッファごとに読み込み
    for (line in br.readLines()) {
        if (line != null) {
            sb += line
        }
    }
    // クローズ
    br.close()

    return sb.toString()
}

// メイン関数
fun main() = application {
    Window(
        onCloseRequest = ::exitApplication,
        title = "住所アプリ",
        state = WindowState(width = 400.dp, height = 700.dp)
    ) {
        MaterialTheme {
            Screen()
        }
    }
}
