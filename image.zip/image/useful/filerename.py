import os
import glob

path = ".hoge"
path2 = "hogehoge"
j_files = glob.glob(path + '/*.jpg')
t_files = glob.glob(path2 + '/*.txt')

for f in j_files:
    os.rename(f, os.path.join(path, 'gray_' + os.path.basename(f)))

for f2 in t_files:
    os.rename(f2, os.path.join(path2, 'gray_' + os.path.basename(f2)))