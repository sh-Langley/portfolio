import shutil

path_old = 'hoge'
fold = input("フォルダ名を指定:")
path_new = 'hoge/' + str(fold)

shutil.copytree(path_old, path_new,ignore = shutil.ignore_patterns('*.txt','*.png','*.jpg'))