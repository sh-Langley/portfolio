import os
import cv2
import re
import glob

#保存ディレクトリ指定
f = input(str("保存フォルダ名:"))
if(not os.path.isdir(f)):
        os.mkdir(f)

f = f + "/"
#読み込み指定
ff = input(str("読み込みフォルダ名:")) + "/"
#ファイル名を指定
types = ("mov","mp4")
files = []
for id in types:
    files += glob.glob(ff+"*."+id)

for data in files:
    data = data.split("\\")[1]
    dir_save = re.sub('(?=\\.).*' , '',data)

    print(dir_save)

# 保存用ディレクトリを作成
    if(not os.path.isdir(f + dir_save)):
        os.mkdir(f + dir_save)

# 動画ファイルの読み込み
    cap = cv2.VideoCapture(ff + data)

# フレーム数を取得&確認
    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    print('総フレーム数: ', frame_count)

# threadフレームごとに画像を保存
    count = 0
    thread = 6
    for i in range(frame_count):
        count += 1
    # フレームを取得
        ret, frame = cap.read()
        if(count == thread):
        # 画像を保存
            jpg = cv2.rotate(frame,cv2.ROTATE_90_CLOCKWISE)
            cv2.imwrite(f'{f}{dir_save}/{dir_save}_{int(i/thread):03}.jpg', jpg)
            count = 0

# キャプチャを閉じる
cap.release()