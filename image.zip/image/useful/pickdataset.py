import random
import glob
import os
import shutil

f = glob.glob("hoge/*.jpg")

a = random.sample(f,800)
for data in a:
    b = data.split("\\")[1]
    jpg_path = data.replace("\\","/")
    print(jpg_path)
    txt_path = "hoge/" + str(b).split(".")[0] + ".txt"
    print(txt_path,"\n")

    shutil.move(jpg_path, 'hoge')
    shutil.move(txt_path, 'hogehoge')
