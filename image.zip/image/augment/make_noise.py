import cv2
import glob

def main():
    # 元画像の読み出しパス指定
    f = glob.glob("hoge/*.jpg")
    for data in f:
        image = cv2.imread()

        SCALE=0.8
        height=image.shape[0]
        width=image.shape[1]
        # 収縮処理
        erode=cv2.resize(image,(round(width*SCALE),round(height*SCALE)),
                        interpolation=cv2.INTER_NEAREST)
        # 収縮後の画素をそのまま補間せずに膨張させる
        mosaic = cv2.resize(erode, (round(width), round(height)),
                            interpolation=cv2.INTER_NEAREST)

        mosaic.save(data)

if __name__=="__main__":
    main()