import tensorflow as tf
from keras.src.legacy.preprocessing.image import ImageDataGenerator
from keras.utils import load_img,img_to_array
import numpy as np
import glob
import shutil
import cv2
import os

image_path = glob.glob('hoge/*.jpg')
save_dir = 'hogehoge'
txt_path = 'hogehogehoge'
save_txt = 'hogehogehogehoge'

for d in image_path:
    datagen = ImageDataGenerator(channel_shift_range = 100)

    image = load_img(d)
    image_array = img_to_array(image)
    image_array = np.expand_dims(image_array, axis=0)
    save_prefix = d.split("\\")[1].split(".")[0]

    augmented_generator = datagen.flow(image_array, batch_size=1, save_to_dir=save_dir, save_prefix=save_prefix, save_format='jpg')\

    for i in range(5):
        next(augmented_generator)

    txt_file = glob.glob(save_dir + save_prefix + "*.jpg")
    for data in txt_file:
        name = data.split("\\")[1].split(".")[0]
        txt_file_name = save_txt + name + ".txt"
        copydata = txt_path+save_prefix+'.txt'
        shutil.copy(copydata, txt_file_name)