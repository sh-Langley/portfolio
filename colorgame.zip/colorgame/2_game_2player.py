import numpy as np
import cv2
import time

class Tile():
    def __init__(self, img, matrix):
        self.mapimg = img
        self.base = matrix
        self.board = self.make_board()
        self.h,self.w = self.h_w()
        self.index = self.select()

    def make_board(self):
        return np.zeros((300,300,3),np.uint8)

    def h_w(self):
        return self.mapimg.shape[:2]

    def select(self):
        return list(zip(*np.where(self.base == 1)))

    def paste_map(self):
        for i in self.index:
            H = i[0] * 100
            W = i[1] * 100
            self.board[H:H + self.h, W:W + self.w] = self.mapimg

        return self.board

def tile_matrix():
    T = np.zeros((3,3))
    count = 0
    while True:
        point = np.random.randint(0,3,2)
        if (T[point[0]][point[1]] == 0):
            T[point[0]][point[1]] = 1
            count += 1

        if (count == 3):
           break

    return T

def make_png():
    board1 = np.zeros((100,100,3),np.uint8)
    board2 = np.zeros((100,100,3),np.uint8)
    board3 = np.zeros((300,300,3),np.uint8)

    cv2.rectangle(board1,(0,0),(100,100),color = (255,0,0),thickness = -1)
    cv2.rectangle(board2,(0,0),(100,100),color = (0,0,255),thickness = -1)

    cv2.imwrite("Blue.png",board1)
    cv2.imwrite("Red.png",board2)
    cv2.imwrite("Black.png",board3)

def view_grid(board):
    y_step = 100
    x_step = 100

    board_y,board_x = board.shape[:2]
    board[y_step:board_y:y_step, :, :] = 255
    board[:, x_step:board_x:x_step, :] = 255
    cv2.imshow('Game Board',board)
    cv2.waitKey(1000)

def _rot(IMG,DEG):
    if(DEG == 0):
        d = input("何回転させますか:")

        if(d.isdecimal() == True):
            IMG = np.rot90(IMG,-int(d))

        else:
            print("再入力")
            IMG = _rot(IMG,0)

    elif(DEG == 1):
        d = np.random.randint(0,4)
        print(f'{d}{"回転です"}')
        IMG = np.rot90(IMG,-d)

    return IMG

def add_card(ID,degit):
    global game_board
    select_card = _rot(cv2.imread(ID + ".png"),degit)
    game_board = cv2.addWeighted(game_board,0.9,select_card,1,0)
    view_grid(game_board)

def check_var(s):
    if(s.isdecimal() == True):
        if(1 <= int(s) and int(s) <= 9):
            pass

        else:
            s = check_var(input("番号を再入力してください:"))

    else:
        s = check_var(input("番号を再入力してください:"))

    return int(s)

def view_card_grid(color):
    board = np.ones((900,900,3),np.uint8) * 255
    count = 1

    for i in range(3):
        for j in range(3):
            img = cv2.imread(color + str(count) + ".png")
            h,w = img.shape[:2]

            H = i * 300
            W = j * 300
            board[H:H+h, W:W+w] = img
            count += 1

    y_step = 300
    x_step = 300

    board_y,board_x = board.shape[:2]
    board[y_step:board_y:y_step, :, :] = 255
    board[:, x_step:board_x:x_step, :] = 255

    cv2.imwrite(color + "_grid.png",board)

def main():
    global game_board
    #元画像の作成
    make_png()

    #手札の作成
    img1 = cv2.imread("Blue.png")
    img2 = cv2.imread("Red.png")

    for i in range(1,10):
        base_matrix = tile_matrix()
        t = Tile(img1,base_matrix)
        tag = t.paste_map()
        cv2.imwrite("Blue" + str(i) + ".png",tag)

    for i in range(1,10):
        base_matrix = tile_matrix()
        t = Tile(img2,base_matrix)
        tag = t.paste_map()
        cv2.imwrite("Red" + str(i) + ".png",tag)

    #手札一覧
    view_card_grid("Red")
    view_card_grid("Blue")

    Red = cv2.imread("Red_grid.png")
    Blue = cv2.imread("Blue_grid.png")
    merge = np.hstack((Red, Blue))
    w,h = merge.shape[:2]
    re_merge = cv2.resize(merge, (int(w * 0.9), int(h * 0.25)))
    cv2.imshow("All Card",re_merge)
    print("キー入力してください")
    cv2.waitKey(0)

    a = np.arange(1,10)
    blue_id = np.random.permutation(a)

    prop = cv2.imread("Black.png")
    game_board = np.zeros((300,300,3),np.uint8)

    for i in range(9):
        print(f'{i+1}{"ターン目"}')
        id = check_var(input("Red:どの番号の札を出しますか:"))
        data = str("Red" + str(id))
        add_card(data,0)
        id = check_var(input("Blue:どの番号の札を出しますか:"))
        data = str("Blue" + str(id))
        add_card(data,0)

        h = game_board.shape[0]
        w = game_board.shape[1]

        for iy in range(h):
            for ix in range(w):
                game_board[iy,ix][0] *= 0.9

    cv2.imshow("Result",game_board)
    print("終わりです.キー入力してください")
    cv2.waitKey(0)
    cv2.imwrite("result.png",game_board)
    time.sleep(1)

    b, g, r, _ = cv2.mean(game_board)

    if(r > b):
        print(f'{"Redの勝利！ Red score = "}{str(r)}{"  Blue score = "}{b}')

    elif(r < b):
        print(f'{"Blueの勝利！ Blue score = "}{str(b)}{"  Red score = "}{r}')

    elif(r == b):
        print(f'{"引き分け！ score = "}{str(b)}')

if __name__ == "__main__":
    main()