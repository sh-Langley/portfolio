import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import sys
import tkinter as tk

#整数のチェック関数
def check(date):

    if not date.isdigit():
        # 妥当でない（半角数字でない）場合はFalseを返却
        return False

    # 妥当（半角数字である）の場合はTrueを返却
    return True

#入力値をリセットする関数
def clear():
    entry_1.delete(0, tk.END)
    entry_2.delete(0, tk.END)
    entry_3.delete(0, tk.END)
    entry_4.delete(0, tk.END)
    entry_5.delete(0, tk.END)

#データを計算してグラフ化する関数
def WBGT():
    xs = []
    ys = []
    def make_plot(x, y):
        xs.append(x)  # 座標を追加
        ys.append(y)  # 座標を追加
        plt.cla()     # 直前に描画したグラフを消す
        plt.plot(xs, ys,color="r",marker='.',label="危険度")
        plt.legend(prop={"family":"MS Gothic"})
        plt.grid()
        plt.pause(.01)

    temp=int(entry_1.get())
    Humi=int(entry_2.get())
    wind=int(entry_3.get())
    time=int(entry_4.get())
    METS=int(entry_5.get())
    wbgt=(0.735*temp)+(0.0374*Humi)+(0.00292*temp*Humi)-(0.0572*wind)-4.064

    s=1/METS
    k=METS*0.05 

    x=0
    if wbgt < 21:
            p=per=10
            make_plot(0, per)

    elif wbgt < 25:
            p=per=15
            make_plot(0, per)

    elif wbgt < 28:
            p=per=30
            make_plot(0, per)

    elif wbgt < 31:
            p=per=50
            make_plot(0, per)

    else:
            sub_win = tk.Toplevel()
            sub_win.title("WARNING!!")
            label_sub = tk.Label(sub_win,text=u'運動を中止してください！', foreground='#ff0000',font=("MS Gothic",100))
            label_sub.pack()
            app.mainloop()
            sys.exit()

    for i in range(time):
            per=per+(((0.0735*temp)+(0.00374*Humi)+(0.000292*temp*Humi))*(i+k+1)-(0.00572*wind)-0.4064)
            make_plot(i+1, per)

    plt.minorticks_on()
    plt.grid(color='#808080', linestyle='dotted', linewidth=0.5)
    plt.axhline(y=(p+(((0.0735*temp)+(0.00374*Humi)+(0.000292*temp*Humi))-(0.00572*wind)-0.4064))*(1+s),color="g",label="危険度の基底値") 
    plt.legend(prop={"family":"MS Gothic"})
    plt.xticks(np.arange(0, time+0.1, step=0.5))
    plt.title("熱中症危険度",fontname="MS Gothic")
    plt.xlabel("経過時間(h)",fontname="MS Gothic")
    plt.ylabel("危険度(%)",fontname="MS Gothic")
    plt.text(time+0.26,p,"wbgt={}".format(int(wbgt)),fontsize=15)
    plt.show()

if __name__ == "__main__":
    app = tk.Tk()
    app.title("熱中症アプリ")
    app.geometry("500x700")
    tcl_check = app.register(check)

    fonts = ("", 30)

    label_title = tk.Label(text='値を整数で入力してください',font=fonts)
    label_title.place(x = 15,y = 0)
    label_1 = tk.Label(text='気温',font=fonts)
    label_1.place(x = 130,y = 70)
    entry_1 = tk.Entry(app,font=fonts,validate='key',vcmd=(tcl_check, '%S'))
    entry_1.place(x = 220,y = 60,width=140,height=70)
    label_2 = tk.Label(text='湿度',font=fonts)
    label_2.place(x = 130,y = 185)
    entry_2 = tk.Entry(app,font=fonts,validate='key',vcmd=(tcl_check, '%S'))
    entry_2.place(x = 220,y = 175,width=140,height=70)
    label_3 = tk.Label(text='風速',font=fonts)
    label_3.place(x = 130,y = 300)
    entry_3 = tk.Entry(app,font=fonts,validate='key',vcmd=(tcl_check, '%S'))
    entry_3.place(x = 220,y = 290,width=140,height=70)
    label_4 = tk.Label(text='活動時間(h)',font=fonts)
    label_4.place(x = 10,y = 415)
    entry_4 = tk.Entry(app,font=fonts,validate='key',vcmd=(tcl_check, '%S'))
    entry_4.place(x = 220,y = 405,width=140,height=70)
    label_5 = tk.Label(text='運動強度',font=fonts)
    label_5.place(x = 50,y = 530)
    entry_5 = tk.Entry(app,font=fonts,validate='key',vcmd=(tcl_check, '%S'))
    entry_5.place(x = 220,y = 520,width=140,height=70)
    button_execute = tk.Button(app, text="実行",font=fonts,command=lambda:[WBGT(),clear()])
    button_execute.place(x = 180,y = 625,width=140,height=70)

    def on_key1(event):
        entry_2.focus_set()

    entry_1.bind("<Key-Return>", on_key1)

    def on_key2(event):
        entry_3.focus_set()

    entry_2.bind("<Key-Return>", on_key2)

    def on_key3(event):
        entry_4.focus_set()

    entry_3.bind("<Key-Return>", on_key3)

    def on_key4(event):
        entry_5.focus_set()

    entry_4.bind("<Key-Return>", on_key4)

    def on_key5(event):
        button_execute.focus_set()

    entry_5.bind("<Key-Return>", on_key5)

    button_execute.bind('<Key-Return>', lambda event:[WBGT(),clear()])

    app.mainloop()