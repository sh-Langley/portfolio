import csv
from matplotlib import pyplot as plt
import pandas as pd
import tkinter as tk
import tkinter.ttk as ttk
import numpy as np

#平均気温(℃),降水量の合計(mm),最高気温(℃),最低気温(℃),天気概況(昼：06時～18時),天気概況(夜：18時～翌日06時),平均湿度(％),平均風速(m/s)

def main():
    global combo_x
    global combo_y
    global combo_f

    label1 = tk.Label(root,text="第1要素を選択してください")
    label1.pack()
    option = ["平均気温", "降水量", "最高気温", "最低気温","平均湿度","平均風速"]  # 選択肢
    variable = tk.StringVar()
    combo_x = ttk.Combobox(root,values=option,textvariable=variable)
    combo_x.bind("<<ComboboxSelected>>",combo_selected_x)
    combo_x.pack()

    label2 = tk.Label(root,text="第2要素を選択してください")
    label2.pack()
    option = ["平均気温", "降水量", "最高気温", "最低気温","平均湿度","平均風速"]  # 選択肢
    variable = tk.StringVar()
    combo_y = ttk.Combobox(root,values=option,textvariable=variable)
    combo_y.bind("<<ComboboxSelected>>",combo_selected_y)
    combo_y.pack()

    label3=tk.Label(root,text="都市名を選択してください")
    label3.pack()
    option = ["Hiroshima","Yamaguchi","Kyoto","Matue","Okayama","Tokyo","Tottori"]  # 選択肢
    variable = tk.StringVar()
    combo_f=ttk.Combobox(root,values=option,textvariable=variable)
    combo_f.bind("<<ComboboxSelected>>",combo_selected_f)
    combo_f.pack()

    button_execute = tk.Button(root, font=("",20),text="実行",command = graph)
    button_execute.bind('<Key-Return>',graph)
    button_execute.pack()

def combo_selected_x(event):
    global combo_x
    print(f'{"第1要素に"}{combo_x.get()}{"が選択されました"}')

def combo_selected_y(event):
    global combo_y
    print(f'{"第2要素に"}{combo_y.get()}{"が選択されました"}')

def combo_selected_f(event):
    global combo_y
    print(f'{"都市名："}{combo_f.get()}{"が選択されました"}')

def graph():
    global combo_x
    global combo_y
    global combo_f

    xc = combo_x.get()
    yc = combo_y.get()
    X = con(xc)
    Y = con(yc)

    plt.figure()
    plt.grid(color='#808080', linestyle='dotted', linewidth=0.5)
    plt.scatter(X,Y)
    plt.title('都市名:' + combo_f.get() + 'の' + xc + 'と' + yc + 'の散布図',fontname="MS Gothic")
    plt.xlabel(xc,fontname="MS Gothic")
    plt.ylabel(yc,fontname="MS Gothic")
    plt.show()

def data(i):
    global combo_f
    df = pd.DataFrame()
    f_name = combo_f.get()
    df = pd.read_csv(f_name + '.csv',skiprows = 1, usecols=[i])
    return df

def con(element):

    z = []

    if(element == '平均気温'):
        i = 4
        z = data(i)
        return z

    elif(element == '降水量'):
        i = 5
        z = data(i)
        return z

    elif(element == '最高気温'):
        i = 6
        z = data(i)
        return z

    elif(element == '最低気温'):
        i = 7
        z = data(i)
        return z

    elif(element == '平均湿度'):
        i = 10
        z = data(i)
        return z

    elif(element == '平均風速'):
        i = 11
        z = data(i)
        return z

if __name__=="__main__":
    root = tk.Tk()
    root.geometry("300x200")
    root.title("気象分析")
    combo_x = str()
    combo_y = str()
    combo_f = str()
    main()
    root.mainloop()